export function canvasWidht(){
    let width = document.getElementById("workAreaRoot").offsetWidth
    return width;
}
export function canvasHeight(){
    let height = document.getElementById("workAreaRoot").offsetHeight
    return height;
}