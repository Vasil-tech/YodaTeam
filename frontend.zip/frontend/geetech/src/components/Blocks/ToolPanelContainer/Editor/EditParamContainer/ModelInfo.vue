<template>
    <div class="ModelInfoRoot">
        <p>Информация о модели</p>
        <p>Объем файла: {{}}</p>
        
    </div>
</template>

<script>
export default{
    data(){
        return{
            fileSize: null,
        }
    }
}
</script>

<style>

</style>
