<template>
    <div class="AuthPageRoot">
        <h2>{{title}}</h2>
        <div class="inputs" v-if="AuthForm">
            <p>Логин</p>
            <input id="loginInput" type="text">
            <p>Пароль</p>
            <input id="passwordInput" type="password">
            <p v-show="fieldAlert">Введите данные корректно</p>
        </div>
        <div class="inputs" v-if="RegistForm">
            <p>E-mail</p>
            <input>
            <p>Логин</p>
            <input>
            <p>Пароль</p>
            <input type="password">
        </div>
        <button @click="fieldAlertCheck()">Вход</button>
    </div>
</template>

<script>
import jsonGenerate from "../scripts/JSONgenerate.js"
export default {
    props:{
        way: String,
        title: String
    },
    data(){
        return{
            AuthForm: false,
            RegistForm: false,
            fieldAlert: false
        }
    },
    created: function(){
        this.showAuth()
    },
    updated(){
        this.showAuth()
    },
    methods:{
        showAuth(){
        if(this.way == "Registration"){
        this.RegistForm = true;
        this.AuthForm = false
            }
        else if(this.way == "Authorisation"){
            this.AuthForm = true;
            this.RegistForm = false
            }
        },
    fieldAlertCheck(){
        if(document.getElementById("loginInput").value.length < 3 || document.getElementById("passwordInput").value.length <= 8){
            this.fieldAlert = true;
        }
        else{ 
            this.fieldAlert = false
            jsonGenerate({ action: this.way, login: document.getElementById("loginInput").value, password: document.getElementById("passwordInput").value})
        }
    }
    }
}

</script>

<style>

</style>